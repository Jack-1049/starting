% rotateframe   Rotate a frame around a given axis
%
%    ori_rot = rotateframe(ori,nRot,rho)
%
%    Rotates a frame described by the three Euler angles in ori around the axis
%    given in nRot by the rotation angles listed in rho.
%
%    Input:
%     ori    Euler angles describing the frame orientation
%     nRot   rotation axis
%               e.g., nRot = [1;0;0] is the x axis
%               does not need to be normalized 
%     rho    rotation angle, or list of rotation angles, for the rotation
%               around nRot
%
%    Output:
%     ori_rot  list of Euler angle sets for the rotated frames, one per row.
%
%    Example:
%       ori0 = [0 45 0]*pi/180;
%       nRot = [1;0;0];
%       rho = (0:30:180)*pi/180;
%       ori_rot = rotateframe(ori0,nRot,rho);
