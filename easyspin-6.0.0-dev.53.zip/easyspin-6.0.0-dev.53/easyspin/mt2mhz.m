% mt2mhz   obsolete
% use unitconvert(input, 'mT->MHz')
