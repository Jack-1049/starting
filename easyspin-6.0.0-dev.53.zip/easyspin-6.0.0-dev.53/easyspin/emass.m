% emass  Electron mass 
%
%   me = emass
%   [me,sigma] = emass
%
%   Returns the mass of the electron in SI units, kg.
%   sigma is the standard uncertainty.
