% diptensor  Calculate dipolar coupling tensor between two spins
%
%   T = diptensor(spin1,spin2,rvec)
%
% Calculates the dipolar coupling tensor T (3x3 matrix, in MHz) between spin1
% and spin2, using the inter-spin distance vector rvec (in nm).
%
% The tensor T is for the Hamiltonian H = J1*T*J2, where J1 is the spin vector
% operator of spin1, and J2 is the spin vector operator for spin2, both in
% units of hbar.
%
% Inputs:
%   spin1  type of first spin: 'e', '1H', '14N', etc.
%   spin2  type of second spin: 'e', '1H', '14N', etc.
%   rvec   3-element vector pointing from spin1 to spin2, in nm
%
% Outputs:
%   T      dipolar coupling tensor (3x3 matrix), in MHz
%
% For electrons, g = gfree = 2.002319... is used.
