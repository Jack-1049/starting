% saffron    Simulate pulse EPR spectra
%
%     S = saffron(Sys,Exp,Opt)
%     [x,S] = saffron(Sys,Exp,Opt)
%     [x,S,out] = saffron(Sys,Exp,Opt)
%
%     Sys   ... spin system with electron spin and ESEEM nuclei
%     Exp   ... experimental parameters (time unit µs)
%     Opt   ... simulation options
%
%     out:
%       x       ... axis for S, contains indirect dimensions and for
%                   transient detection time axis of transient, frequency
%                   axis for ENDOR
%       S       ... simulated signal (ESEEM) or spectrum (ENDOR)
%       out     ... structure with FFT of ESEEM signal
