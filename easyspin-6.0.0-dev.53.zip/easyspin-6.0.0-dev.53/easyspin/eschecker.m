% ESCHECKER   EasySpin expiry checker
%
%    eschecker
%
% Checks whether the installed version of EasySpin has expired.
