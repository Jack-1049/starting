% mhz2mt   obsolete
% use unitconvert(input, 'MHz->mT')
