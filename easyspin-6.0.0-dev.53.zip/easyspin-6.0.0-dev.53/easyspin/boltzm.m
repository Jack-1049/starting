% boltzm  Boltzmann constant 
%
%   k = boltzm
%
%   Returns the Boltzmann constant in SI units, joule per kelvin.
