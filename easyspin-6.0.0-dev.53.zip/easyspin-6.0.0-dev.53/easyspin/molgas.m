% molgas  molar gas constant 
%
%   R = molgas
%
%   Returns the molar gas constant in SI units, joule per mole per kelvin.
