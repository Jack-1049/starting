% rescaledata    Rescaling of one data vector so that it fits a second
%
%   ynew = rescaledata(y,mode1)
%   ynew = rescaledata(y,yref,mode2)
%   [ynew, scalefactors] = rescaledata(...)
%
%   Shifts and rescales the data vector y. If given, yref serves
%   as the reference. The rescaled y is returned in ynew. scalefactors
%   includes a list of scale factors that were applied to y to give ynew.
%
%   y and yref must be 1D vectors.
%
% Inputs:
%   mode1:
%     'minmax'  shifts and scales so that minimum is 0 and maximum is 1
%     'maxabs'  scales such that maximum magnitude is 1, no shift
%     'none'    no scaling
%
%   mode2:
%     'minmax'  shifts and scales so that minimum and maximum of ynew
%               fit the minimum and maximum of yref
%     'maxabs'  scales y so that maximum absolute values of ynew fits yref
%     'lsq'     least-squares fit of a*y to yref
%     'lsq0'    least-squares fit of a*y+b to yref
%     'lsq1'    least-squares fit of a*y+b+c*x to yref
%     'lsq2'    least-squares fit of a*y+b+c*x+d*x^2 to yref
%     'lsq3'    least-squares fit of a*y+b+c*x+d*x^2+e*x^3 to yref
%     'none'    no scaling
%
%   Positive scaling is enforced, i.e. the rescaled data is never inverted.
%
% Output:
%   ynew          the new rescaled y vector
%   scalefactors  the scaling factors and polynomial coefficients
