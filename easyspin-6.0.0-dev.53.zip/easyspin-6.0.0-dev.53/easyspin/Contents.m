% EasySpin - a toolbox for simulating Electron Paramagnetic Resonance spectra
%
%    Visit easyspin.org for the lastest version
%    and to access the full documentation.
%
